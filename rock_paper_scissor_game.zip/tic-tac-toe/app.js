    let [computer,user]=[0,0];
    let result_ref = document.getElementById("result");
    let exit=document.getElementById("exit");

    let icon1=document.getElementById("icon1");
    let icon2=document.getElementById("icon2");
    let icon3=document.getElementById("icon3");
    
    let icon_1=document.getElementById("icon_1");
    let icon_2=document.getElementById("icon_2");
    let icon_3=document.getElementById("icon_3");


    let choices_object ={
    'rock' : {
        'rock' : 'draw',
        'scissor' : 'win',
        'paper' : 'lose'
    },
    'scissor' : {
        'rock' : 'lose',
        'scissor' : 'draw',
        'paper' : 'win'
    },
    'paper' : {
        'rock' : 'win',
        'scissor' : 'lose',
        'paper' : 'draw'
    }
};
let t=0;
function fun(){
    t=10;
}
function fun1(){
   window.location.href='index2.html';
}


let turn=0;
function checker(input){
    turn++;
    var choices =["rock" , "scissor" ,"paper"];
    var num=Math.floor(Math.random()*3);

    document.getElementById("comp_choice").
    innerHTML=
    `Computer choose : <span> ${choices[num].
    toUpperCase()} </span>`;

    document.getElementById("user_choice").
    innerHTML =
    `You choose : <span> ${input.toUpperCase()} </span>`;

    document.getElementById("p").
    innerHTML = ``;
    
    if(input=="rock"){
        icon1.style.height="100px";
        icon1.style.width="100px";
        icon1.style.borderColor="white";
        icon1.style.top="92px";
        icon1.style.left="625px";
        icon1.style.borderWidth="3px";
        icon1.style.boxShadow="0 0px 15px rgb(249, 3, 204) inset, 0 0px 15px rgb(249, 3, 204),0 0px 15px rgb(249, 3, 204) inset, 0 0px 15px rgb(249, 3, 204)";

        icon2.style.height="80px";
        icon2.style.width="80px";
        icon2.style.borderColor="rgb(241, 249, 3)";
        icon2.style.top="208px";
        icon2.style.left="636px";
        icon2.style.borderWidth="1px";
        icon2.style.boxShadow="0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3),0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3)";

        icon3.style.height="80px";
        icon3.style.width="80px";
        icon3.style.borderColor="rgb(3, 138, 249)";
        icon3.style.top="316px";
        icon3.style.left="636px";
        icon3.style.borderWidth="1px";
        icon3.style.boxShadow="0 0px 10px rgb(3, 130, 249) inset, 0 0px 10px rgb(3, 138, 249),0 0px 10px rgb(3, 138, 249) inset, 0 0px 10px rgb(3, 138, 249)";
    }
    if(input=="scissor"){
        icon2.style.height="100px";
        icon2.style.width="100px";
        icon2.style.borderColor="white";
        icon2.style.top="200px";
        icon2.style.left="625px";
        icon2.style.borderWidth="3px";
        icon2.style.boxShadow="0 0px 15px rgb(241, 249, 3) inset, 0 0px 15px rgb(241, 249, 3),0 0px 15px rgb(241, 249, 3) inset, 0 0px 15px rgb(241, 249, 3)";

        
        icon3.style.top="316px";
        icon3.style.height="80px";
        icon3.style.width="80px";
        icon3.style.left="636px";
        icon3.style.borderColor="rgb(3, 138, 249)";
        icon3.style.borderWidth="1px";
        icon3.style.boxShadow="0 0px 10px rgb(3, 130, 249) inset, 0 0px 10px rgb(3, 138, 249),0 0px 10px rgb(3, 138, 249) inset, 0 0px 10px rgb(3, 138, 249)";

        icon1.style.height="80px";
        icon1.style.width="80px";
        icon1.style.borderColor="rgb(249, 3, 204)";
        icon1.style.top="100px";
        icon1.style.left="636px";
        icon1.style.borderWidth="1px";
        icon1.style.boxShadow="0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204),0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204)";


    }
    if(input=="paper"){
        icon3.style.height="100px";
        icon3.style.width="100px";
        icon3.style.borderColor="white";
        icon3.style.top="302px";
        icon3.style.left="625px";
        icon3.style.borderWidth="3px";
        icon3.style.boxShadow="0 0px 15px rgb(3, 130, 249) inset, 0 0px 15px rgb(3, 138, 249),0 0px 15px rgb(3, 138, 249) inset, 0 0px 15px rgb(3, 138, 249)";

        icon2.style.height="80px";
        icon2.style.width="80px";
        icon2.style.borderColor="rgb(241, 249, 3)";
        icon2.style.top="208px";
        icon2.style.left="636px";
        icon2.style.borderWidth="1px";
        icon2.style.boxShadow="0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3),0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3)";


        icon1.style.height="80px";
        icon1.style.width="80px";
        icon1.style.borderColor="rgb(249, 3, 204)";
        icon1.style.top="100px";
        icon1.style.left="636px";
        icon1.style.borderWidth="1px";
        icon1.style.boxShadow="0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204),0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204)";
    }
    if(choices[num]=="rock"){
        icon_1.style.height="100px";
        icon_1.style.width="100px";
        icon_1.style.borderColor="white";
        icon_1.style.left="-130px";
        icon_1.style.top="92px";
        icon_1.style.borderWidth="3px";
        icon_1.style.boxShadow="0 0px 15px rgb(249, 3, 204) inset, 0 0px 15px rgb(249, 3, 204),0 0px 15px rgb(249, 3, 204) inset, 0 0px 15px rgb(249, 3, 204)";

        icon_2.style.height="80px";
        icon_2.style.width="80px";
        icon_2.style.borderColor="rgb(241, 249, 3)";
        icon_2.style.left="-120px";
        icon_2.style.top="208px";
        icon_2.style.borderWidth="1px";
        icon_2.style.boxShadow="0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3),0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3)";

        icon_3.style.height="80px";
        icon_3.style.width="80px";
        icon_3.style.borderColor="rgb(3, 138, 249)";
        icon_3.style.left="-120px";
        icon_3.style.top="316px";
        icon_3.style.borderWidth="1px";
        icon_3.style.boxShadow="0 0px 10px rgb(3, 130, 249) inset, 0 0px 10px rgb(3, 138, 249),0 0px 10px rgb(3, 138, 249) inset, 0 0px 10px rgb(3, 138, 249)";
    }
    if(choices[num]=="scissor"){
        icon_2.style.height="100px";
        icon_2.style.width="100px";
        icon_2.style.borderColor="white";
        icon_2.style.left="-130px";
        icon_2.style.top="200px";
        icon_2.style.borderWidth="3px";
        icon_2.style.boxShadow="0 0px 15px rgb(241, 249, 3) inset, 0 0px 15px rgb(241, 249, 3),0 0px 15px rgb(241, 249, 3) inset, 0 0px 15px rgb(241, 249, 3)";

        
        icon_3.style.top="316px";
        icon_3.style.height="80px";
        icon_3.style.width="80px";
        icon_3.style.borderColor="rgb(3, 138, 249)";
        icon_3.style.left="-120px";
        icon_3.style.borderWidth="1px";
        icon_3.style.boxShadow="0 0px 10px rgb(3, 130, 249) inset, 0 0px 10px rgb(3, 138, 249),0 0px 10px rgb(3, 138, 249) inset, 0 0px 10px rgb(3, 138, 249)";

        icon_1.style.height="80px";
        icon_1.style.width="80px";
        icon_1.style.borderColor="rgb(249, 3, 204)";
        icon_1.style.left="-120px";
        icon_1.style.top="100px";
        icon_1.style.borderWidth="1px";
        icon_1.style.boxShadow="0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204),0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204)";


    }
    if(choices[num]=="paper"){
        icon_3.style.height="100px";
        icon_3.style.width="100px";
        icon_3.style.borderColor="white";
        icon_3.style.left="-130px";
        icon_3.style.top="302px";
        icon_3.style.borderWidth="3px";
        icon_3.style.boxShadow="0 0px 15px rgb(3, 130, 249) inset, 0 0px 15px rgb(3, 138, 249),0 0px 15px rgb(3, 138, 249) inset, 0 0px 15px rgb(3, 138, 249)";

        icon_2.style.height="80px";
        icon_2.style.width="80px";
        icon_2.style.borderColor="rgb(241, 249, 3)";
        icon_2.style.left="-120px";
        icon_2.style.top="208px";
        icon_2.style.borderWidth="1px";
        icon_2.style.boxShadow="0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3),0 0px 10px rgb(241, 249, 3) inset, 0 0px 10px rgb(241, 249, 3)";


        icon_1.style.height="80px";
        icon_1.style.width="80px";
        icon_1.style.borderColor="rgb(249, 3, 204)";
        icon_1.style.left="-120px";
        icon_1.style.top="100px";
        icon_1.style.borderWidth="1px";
        icon_1.style.boxShadow="0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204),0 0px 10px rgb(249, 3, 204) inset, 0 0px 10px rgb(249, 3, 204)";
    }

    let com_choice=choices[num];
    switch(choices_object[input][com_choice]){
        case 'win':
            result_ref.style.cssText =
            "color:rgb(250, 250, 250); text-shadow: 2px 2px 3px rgb(73, 214, 51),-2px 2px 3px rgb(73, 214, 51),-2px -2px 3px rgb(73, 214, 51),2px -2px 3px rgb(373, 214, 51);";
            result_ref.innerHTML = 'YOU WIN';
            user++;
            break;
        case 'lose':
            result_ref.style.cssText =
            "color:rgb(250, 250, 250); text-shadow: 2px 2px 3px rgb(253, 4, 4),-2px 2px 3px rgb(253, 4, 4),-2px -2px 3px rgb(253, 4, 4),2px -2px 3px rgb(253, 4, 4); ";
            result_ref.innerHTML = 'YOU LOSE'; 
            computer++;
            break;
        case 'draw':
            result_ref.style.cssText =
            "color:rgb(250, 250, 250); text-shadow: 2px 2px 3px rgb(190, 4, 252),-2px 2px 3px rgb(190, 4, 252),-2px -2px 3px rgb(190, 4, 252),2px -2px 3px rgb(190, 4, 252);";
            result_ref.innerHTML = 'DRAW';
            break;  
    }

    
   document.getElementById("CS").innerHTML = computer;
   document.getElementById("YS").innerHTML = user;
   switch (turn) {
    case 10:
        
        document.getElementById("comp_choice").
        innerHTML=
        `Your score: <span> ${user} </span>`;

        document.getElementById("user_choice").
        innerHTML =
        `Computer score : <span> ${computer} </span>`;

        if(computer<user){
            result_ref.style.cssText =
            "color:rgb(250, 250, 250); font-size:30px; text-shadow: 2px 2px 3px rgb(73, 214, 51),-2px 2px 3px rgb(73, 214, 51),-2px -2px 3px rgb(73, 214, 51),2px -2px 3px rgb(373, 214, 51);";
            result_ref.innerHTML = 'YOU WON THE GAME';}
        else{
            result_ref.style.cssText =
            "color:rgb(250, 250, 250); font-size:30px; text-shadow: 2px 2px 3px rgb(253, 4, 4),-2px 2px 3px rgb(253, 4, 4),-2px -2px 3px rgb(253, 4, 4),2px -2px 3px rgb(253, 4, 4); ";
            result_ref.innerHTML = 'YOU LOST THE GAME';}

        exit.style.cssText="color: red; background-color:black; font-family:cursive; font-size:21px;";
        exit.style.borderWidth='2px';
        exit.style.borderColor='rgb(253, 84, 75)';
        exit.style.borderRadius='20px';
        exit.style.cursor='pointer';
        exit.style.boxShadow='0 0px 10px rgb(252, 62, 62) inset, 0 0px 10px rgb(252, 62, 62),0 0px 10px rgb(252, 62, 62) inset, 0 0px 10px rgb(252, 62, 62)';
        exit.innerHTML = 'Exit';

        icon1.style.pointerEvents="none";

        icon2.style.pointerEvents="none";

        icon3.style.pointerEvents="none";


        let rs=document.getElementById("restart");
        rs.style.color="black";
        rs.style.border="none";
        rs.style.boxShadow="none";
        rs.style.pointerEvents="none";

        let bb=document.getElementById("backtohome");
        bb.style.color="black";
        bb.style.border="none";
        bb.style.boxShadow="none";
        bb.style.pointerEvents="none";
   }
    
}
